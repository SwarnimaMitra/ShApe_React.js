import React from "react";

function Note1()
{
  return (
     <div className="notes">
       <h2>
         Machine Learning
       </h2>
        <p>Machine learning is a method of data analysis that automates analytical model building. It is a branch of artificial intelligence based on the idea that systems can learn from data, identify patterns and make decisions with minimal human intervention</p>
      </div>   
         
  );
}


export default Note1;
